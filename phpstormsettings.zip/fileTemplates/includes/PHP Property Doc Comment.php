/** @var ${TYPE_HINT} */
