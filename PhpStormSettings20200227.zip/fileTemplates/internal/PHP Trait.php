<?php

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

/**
 * Trait ${NAME}
 */
trait ${NAME} {

}