<?php

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

/**
 * Interface ${NAME}
 */
interface ${NAME} {

}