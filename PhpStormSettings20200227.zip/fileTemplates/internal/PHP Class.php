<?php

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

/**
 * Class ${NAME}
 */
class ${NAME}
{

}